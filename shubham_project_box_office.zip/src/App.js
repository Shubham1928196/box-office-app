import React from 'react';
import { Switch, Route } from 'react-router-dom';
function App() {
  return (
    <switch>
      <Route path="/">This is home page</Route>
      Hi
    </switch>
  );
}

export default App;
